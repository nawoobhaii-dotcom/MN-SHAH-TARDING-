# MN SHAH live market-data prototype

## Important
This is a learning/demo project. It fetches candle data through a server-side Twelve Data API key. Its UP/DOWN/WAIT output is a basic EMA/RSI rule, **not AI**, not a validated strategy, and not a promise of profit. Do not use it to place real trades.

## Deploy from an Android phone
1. Create a private GitHub repository and upload these project files (`server.js`, `package.json`, `public/index.html`).
2. Create a Node web service on a hosting provider that supports Node.js deployments from GitHub.
3. Set the start command to `npm start`.
4. In the hosting dashboard, add an environment variable:
   - Name: `TWELVEDATA_API_KEY`
   - Value: your Twelve Data API key
5. Deploy, then open the service URL on your phone.

Never put the API key inside `public/index.html`, a screenshot, a public GitHub repository, or this chat. Keep the repository private. If the key was exposed, revoke/rotate it at Twelve Data.

## Local run
Requires Node.js 18+:
- `TWELVEDATA_API_KEY=your_key npm start`
- Open `http://localhost:3000`

## Current limits
The app requests 40 candles per refresh. Provider plan limits, symbol availability, data delays, and licensing apply. Check Twelve Data's current plan and terms before public use. Some symbols may require a different subscription.
