const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.TWELVEDATA_API_KEY;

function send(res, status, body, type = "application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type": type, "Cache-Control": "no-store"});
  res.end(body);
}
function json(res, status, data) { send(res, status, JSON.stringify(data)); }

function fetchCandles(symbol, interval) {
  return new Promise((resolve, reject) => {
    const url = new URL("https://api.twelvedata.com/time_series");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("interval", interval);
    url.searchParams.set("outputsize", "40");
    url.searchParams.set("apikey", API_KEY);
    https.get(url, (apiRes) => {
      let raw = "";
      apiRes.setEncoding("utf8");
      apiRes.on("data", chunk => raw += chunk);
      apiRes.on("end", () => {
        try {
          const data = JSON.parse(raw);
          if (apiRes.statusCode < 200 || apiRes.statusCode >= 300 || data.status === "error" || !data.values) {
            reject(new Error(data.message || data.code || "Market data provider returned an error"));
            return;
          }
          resolve(data);
        } catch { reject(new Error("Could not read market data response")); }
      });
    }).on("error", reject);
  });
}

const allowedSymbols = new Set(["EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD", "BTC/USD"]);
const allowedIntervals = new Set(["1min", "5min", "15min", "30min", "1h"]);

http.createServer(async (req, res) => {
  const pathname = new URL(req.url, "http://localhost").pathname;
  if (req.method === "GET" && pathname === "/api/health") {
    return json(res, 200, {ok: true, apiKeyConfigured: Boolean(API_KEY)});
  }
  if (req.method === "GET" && pathname === "/api/market") {
    if (!API_KEY) return json(res, 503, {error: "Server API key is not configured. Add TWELVEDATA_API_KEY in hosting environment variables."});
    const u = new URL(req.url, "http://localhost");
    const symbol = u.searchParams.get("symbol") || "EUR/USD";
    const interval = u.searchParams.get("interval") || "1min";
    if (!allowedSymbols.has(symbol) || !allowedIntervals.has(interval)) return json(res, 400, {error: "Unsupported market or timeframe"});
    try {
      const data = await fetchCandles(symbol, interval);
      const values = data.values.slice().reverse().map(v => ({
        time: v.datetime, open: Number(v.open), high: Number(v.high),
        low: Number(v.low), close: Number(v.close)
      }));
      return json(res, 200, {symbol, interval, currency: data.meta && data.meta.currency, values});
    } catch (e) {
      return json(res, 502, {error: e.message});
    }
  }
  const requested = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const file = path.join(__dirname, "public", requested);
  if (!file.startsWith(path.join(__dirname, "public"))) return send(res, 403, "Forbidden", "text/plain");
  fs.readFile(file, (err, content) => {
    if (err) return send(res, 404, "Not found", "text/plain");
    const ext = path.extname(file);
    const types = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8"};
    send(res, 200, content, types[ext] || "application/octet-stream");
  });
}).listen(PORT, () => console.log(`MN SHAH server listening on ${PORT}`));
